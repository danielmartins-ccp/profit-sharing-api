__version__ = "0.1.0"


def initialize(settings: dict, weights: dict):
    pass
